Steps are use the path:  
  Windows>users>youruser>appdata>local>roblox>ClientSettings.  
  
  Inside this ClientSettings folder you will see IxpSettings.json, rename this file to "IxpSettings(1).json".  
  
  And then download my ZIP.  Extract the files. Inside the files you will see a file called "IxpSettings.json"  copy and paste this file into the ClientSettings folder.

  After this you can just run the .bat in my zip file, and then Fleasion, and it will work.

  (If it stops working after rejoin just re run the zip)


    (THIS IN NO WAY IS MEANT TO BE USED FOR CHEATING/EXPLOITATIONAL PURPOSES)

     (THIS READ ME IS ONLY FOR IF IT DOES NOT INITIALLY WORK, IT SHOULD COMPLETE THIS AUTOMATICALLY)